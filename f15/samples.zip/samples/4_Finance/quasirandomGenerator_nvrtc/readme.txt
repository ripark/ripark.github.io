Sample: Niederreiter Quasirandom Sequence Generator with libNVRTC
Minimum spec: SM 2.0

This sample implements Niederreiter Quasirandom Sequence Generator and Inverse Cumulative Normal Distribution functions for the generation of Standard Normal Distributions, compiling the CUDA kernels involved at runtime using NVRTC.

Key concepts:
Computational Finance
Runtime Compilation
