Sample: Sobol Quasirandom Number Generator
Minimum spec: SM 2.0

This sample implements Sobol Quasirandom Sequence Generator.

Key concepts:
Computational Finance
