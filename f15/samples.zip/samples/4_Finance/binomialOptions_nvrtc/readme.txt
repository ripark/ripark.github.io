Sample: Binomial Option Pricing with libNVRTC
Minimum spec: SM 2.0

This sample evaluates fair call price for a given set of European options under binomial model. This sample makes use of NVRTC for Runtime Compilation.

Key concepts:
Computational Finance
