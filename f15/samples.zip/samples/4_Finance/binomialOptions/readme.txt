Sample: Binomial Option Pricing
Minimum spec: SM 2.0

This sample evaluates fair call price for a given set of European options under binomial model.

Key concepts:
Computational Finance
