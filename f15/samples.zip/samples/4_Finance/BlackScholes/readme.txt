Sample: Black-Scholes Option Pricing
Minimum spec: SM 2.0

This sample evaluates fair call and put prices for a given set of European options by Black-Scholes formula.

Key concepts:
Computational Finance
