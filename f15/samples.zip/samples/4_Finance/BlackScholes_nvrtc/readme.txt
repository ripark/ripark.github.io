Sample: Black-Scholes Option Pricing with libNVRTC
Minimum spec: SM 2.0

This sample evaluates fair call and put prices for a given set of European options by Black-Scholes formula, compiling the CUDA kernels involved at run

Key concepts:
Computational Finance
