Sample: Vector Addition Driver API
Minimum spec: SM 2.0

This Vector Addition sample is a basic sample that is implemented element by element.  It is the same as the sample illustrating Chapter 3 of the programming guide with some additions like error checking.   This sample also uses the new CUDA 4.0 kernel launch Driver API.

Key concepts:
CUDA Driver API
Vector Addition
