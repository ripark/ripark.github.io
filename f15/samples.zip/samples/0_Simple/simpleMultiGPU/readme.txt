Sample: Simple Multi-GPU
Minimum spec: SM 2.0

This application demonstrates how to use the new CUDA 4.0 API for CUDA context management and multi-threaded access to run CUDA kernels on multiple-GPUs.

Key concepts:
Asynchronous Data Transfers
CUDA Streams and Events
Multithreading
Multi-GPU
