Sample: Matrix Multiplication (CUBLAS)
Minimum spec: SM 2.0

This sample implements matrix multiplication from Chapter 3 of the programming guide. To illustrate GPU performance for matrix multiply, this sample also shows how to use the new CUDA 4.0 interface for CUBLAS to demonstrate high-performance performance for matrix multiplication.

Key concepts:
CUDA Runtime API
Performance Strategies
Linear Algebra
CUBLAS
