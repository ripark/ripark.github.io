Sample: simplePrintf
Minimum spec: SM 2.0

This CUDA Runtime API sample is a very basic sample that implements how to use the printf function in the device code.

Key concepts:
Debugging
