Sample: Simple Cubemap Texture
Minimum spec: SM 2.0

Simple example that demonstrates how to use a new CUDA 4.1 feature to support cubemap Textures in CUDA C.

Key concepts:
Texture
Volume Processing
