Sample: Simple Atomic Intrinsics with libNVRTC
Minimum spec: SM 2.0

A simple demonstration of global memory atomic instructions.

Key concepts:
Atomic Intrinsics
Runtime Compilation
