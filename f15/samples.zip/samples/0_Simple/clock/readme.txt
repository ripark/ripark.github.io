Sample: Clock
Minimum spec: SM 2.0

This example shows how to use the clock function to measure the performance of kernel accurately.

Key concepts:
Performance Strategies
