Sample: Simple Templates with libNVRTC
Minimum spec: SM 2.0

This sample is a templatized version of the template project. It also shows how to correctly templatize dynamically allocated shared memory arrays.

Key concepts:
C++ Templates
Runtime Compilation
