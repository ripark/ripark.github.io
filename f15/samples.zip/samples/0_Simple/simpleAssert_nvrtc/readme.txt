Sample: simpleAssert with libNVRTC
Minimum spec: SM 2.0

This CUDA Runtime API sample is a very basic sample that implements how to use the assert function in the device code. Requires Compute Capability 2.0 .

Key concepts:
Assert
Runtime Compilation
