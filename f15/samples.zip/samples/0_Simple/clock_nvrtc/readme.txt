Sample: Clock libNVRTC
Minimum spec: SM 2.0

This example shows how to use the clock function using libNVRTC to measure the performance of kernel accurately.

Key concepts:
Performance Strategies
Runtime Compilation
