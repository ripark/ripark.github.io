Sample: Simple Texture (Driver Version)
Minimum spec: SM 2.0

Simple example that demonstrates use of Textures in CUDA.  This sample uses the new CUDA 4.0 kernel launch Driver API.

Key concepts:
CUDA Driver API
Texture
Image Processing
