Sample: Pitch Linear Texture
Minimum spec: SM 2.0

Use of Pitch Linear Textures

Key concepts:
Texture
Image Processing
