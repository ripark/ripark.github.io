Sample: Fast Walsh Transform
Minimum spec: SM 2.0

Naturally(Hadamard)-ordered Fast Walsh Transform for batching vectors of arbitrary eligible lengths that are power of two in size.

Key concepts:
Linear Algebra
Data-Parallel Algorithms
Video Compression
