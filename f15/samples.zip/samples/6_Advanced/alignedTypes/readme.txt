Sample: Aligned Types
Minimum spec: SM 2.0

A simple test, showing huge access speed gap between aligned and misaligned structures.

Key concepts:
Performance Strategies
