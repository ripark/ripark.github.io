Sample: CUDA C 3D FDTD
Minimum spec: SM 2.0

This sample applies a finite differences time domain progression stencil on a 3D surface.

Key concepts:
Performance Strategies
