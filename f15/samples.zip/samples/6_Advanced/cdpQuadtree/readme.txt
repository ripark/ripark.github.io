Sample: Quad Tree (CUDA Dynamic Parallelism)
Minimum spec: SM 3.5

This sample demonstrates Quad Trees implemented using CUDA Dynamic Parallelism.  This sample requires devices with compute capability 3.5 or higher.

Key concepts:
CUDA Dynamic Parallelism
