Sample: Function Pointers
Minimum spec: SM 2.0

This sample illustrates how to use function pointers and implements the Sobel Edge Detection filter for 8-bit monochrome images.

Key concepts:
Graphics Interop
Image Processing
