Sample: Smoke Particles
Minimum spec: SM 2.0

Smoke simulation with volumetric shadows using half-angle slicing technique. Uses CUDA for procedural simulation, Thrust Library for sorting algorithms, and OpenGL for graphics rendering.

Key concepts:
Graphics Interop
Data Parallel Algorithms
Physically-Based Simulation
