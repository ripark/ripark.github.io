Sample: Post-Process in OpenGL
Minimum spec: SM 2.0

This sample shows how to post-process an image rendered in OpenGL using CUDA.

Key concepts:
Graphics Interop
Image Processing
