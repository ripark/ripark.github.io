Sample: Sobel Filter
Minimum spec: SM 2.0

This sample implements the Sobel edge detection filter for 8-bit monochrome images.

Key concepts:
Graphics Interop
Image Processing
