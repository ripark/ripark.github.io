Sample: DirectX Texture Compressor (DXTC)
Minimum spec: SM 2.0

High Quality DXT Compression using CUDA. This example shows how to implement an existing computationally-intensive CPU compression algorithm in parallel on the GPU, and obtain an order of magnitude performance improvement.

Key concepts:
Image Processing
Image Compression
