Sample: Texture-based Separable Convolution
Minimum spec: SM 2.0

Texture-based implementation of a separable 2D convolution with a gaussian kernel. Used for performance comparison against convolutionSeparable.

Key concepts:
Image Processing
Texture
Data Parallel Algorithms
