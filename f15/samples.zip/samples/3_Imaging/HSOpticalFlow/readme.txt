Sample: Optical Flow
Minimum spec: SM 2.0

Variational optical flow estimation example.  Uses textures for image operations. Shows how simple PDE solver can be accelerated with CUDA.

Key concepts:
Image Processing
Data Parallel Algorithms
