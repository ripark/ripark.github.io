Sample: Recursive Gaussian Filter
Minimum spec: SM 2.0

This sample implements a Gaussian blur using Deriche's recursive method. The advantage of this method is that the execution time is independent of the filter width.

Key concepts:
Graphics Interop
Image Processing
