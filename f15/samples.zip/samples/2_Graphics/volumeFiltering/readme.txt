Sample: Volumetric Filtering with 3D Textures and Surface Writes
Minimum spec: SM 2.0

This sample demonstrates 3D Volumetric Filtering using 3D Textures and 3D Surface Writes.

Key concepts:
Graphics Interop
Image Processing
3D Textures
Surface Writes
