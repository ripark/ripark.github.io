Sample: Simple OpenGLES
Minimum spec: SM 3.2

Demonstrates data exchange between CUDA and OpenGL ES (aka Graphics interop). The program modifies vertex positions with CUDA and uses OpenGL ES to render the geometry.

Key concepts:
Graphics Interop
Vertex Buffers
3D Graphics
