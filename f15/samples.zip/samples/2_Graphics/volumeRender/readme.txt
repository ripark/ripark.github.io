Sample: Volume Rendering with 3D Textures
Minimum spec: SM 2.0

This sample demonstrates basic volume rendering using 3D Textures.

Key concepts:
Graphics Interop
Image Processing
3D Textures
