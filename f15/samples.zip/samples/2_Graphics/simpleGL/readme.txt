Sample: Simple OpenGL
Minimum spec: SM 2.0

Simple program which demonstrates interoperability between CUDA and OpenGL. The program modifies vertex positions with CUDA and uses OpenGL to render the geometry.

Key concepts:
Graphics Interop
Vertex Buffers
3D Graphics
