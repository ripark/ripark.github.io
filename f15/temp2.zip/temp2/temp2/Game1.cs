﻿//Class examples through parallax scrolling.
//Contains code for keyboard input, parallax scrolling, bounding box collisions
//September 23, 2015
//Using sprites from:
//http://bulbapedia.bulbagarden.net/wiki/Professor_Oak
//http://rbwhitaker.wikidot.com/monogame-spritebatch-basics
//https://github.com/davidluzgouveia/ParallaxScrolling/tree/master/ParallaxScrolling/ParallaxScrollingContent

#region Using Statements
using System;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Input;

#endregion

namespace temp2
{


	public class Game1 : Game
	{
		GraphicsDeviceManager graphics;
		SpriteBatch spriteBatch;
		private Texture2D image;
		private Texture2D shuttleimg;
		private Texture2D background1;
		private Texture2D background2;
		private Texture2D background3;
		private int x;
		private int y;
		private int shuttlex;
		private int shuttley;
		private Rectangle ShuttleRectangle;
		private int PLATFORM_TOP;

		public Game1 ()
		{
			graphics = new GraphicsDeviceManager (this);
			Content.RootDirectory = "Content";	            
			graphics.IsFullScreen = true;
			x = 0;
			y = 0;
			shuttlex = 2200; //placing a shuttle off screen as an obstacle!
			shuttley = 0;
		}
			
		protected override void Initialize ()
		{
			base.Initialize ();				
		}
			
		protected override void LoadContent ()
		{
			// Create a new SpriteBatch, which can be used to draw textures.
			spriteBatch = new SpriteBatch (GraphicsDevice);
			PLATFORM_TOP = GraphicsDevice.Viewport.Height - 100;
			image = Content.Load<Texture2D>("Spr_FRLG_Oak");
			y = PLATFORM_TOP - image.Height;
			shuttleimg = Content.Load<Texture2D> ("shuttle");
			shuttley = PLATFORM_TOP - shuttleimg.Height;
			//create a rectangle for collisions
			ShuttleRectangle = new Rectangle (shuttlex, shuttley, shuttleimg.Width, shuttleimg.Height);
			background1 = Content.Load<Texture2D> ("Layer2");
			background2 = Content.Load<Texture2D> ("Layer5");
			background3 = Content.Load<Texture2D> ("Layer8");
		}

		/// Update contains our keyboard code, though up and down are currently commented out
		protected override void Update (GameTime gameTime)
		{
			// For Mobile devices, this logic will close the Game when the Back button is pressed
			// Exit() is obsolete on iOS
			#if !__IOS__
			if (GamePad.GetState (PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
			    Keyboard.GetState ().IsKeyDown (Keys.Escape)) {
				Exit ();
			}
			#endif
			KeyboardState keyboard = Keyboard.GetState ();

			if (keyboard.IsKeyDown (Keys.Escape)) {
				Exit ();
			}
			bool leftDown = keyboard.IsKeyDown (Keys.Left);
			bool rightDown = keyboard.IsKeyDown (Keys.Right);
//			bool upDown = keyboard.IsKeyDown (Keys.Up);
//			bool downDown = keyboard.IsKeyDown (Keys.Down);

			//since we're fixing Prof Oak in space, we don't need to check for the sprite walking off the edge of the screen.
			//if you were to do a more classic Megaman/Super Mario Bros. scrolling, you'd need to allow for the sprite to move
			//and do a check here for if you should scroll the background
			if (leftDown /*&& x>=0*/ && !ShuttleRectangle.Intersects(new Rectangle(195, y, image.Width, image.Height)))
				x-=5;
			if (rightDown /*&& x<=GraphicsDevice.Viewport.Width-image.Width*/ && !ShuttleRectangle.Intersects(new Rectangle(205, y, image.Width, image.Height)))
				x+=5;
//			if (upDown && y>=0 && !ShuttleRectangle.Intersects(new Rectangle(x, y-1, image.Width, image.Height)))
//				y--;
//			if (downDown && y <= GraphicsDevice.Viewport.Height-image.Height && !ShuttleRectangle.Intersects (new Rectangle (x, y + 1, image.Width, image.Height)))
//				y++;
			base.Update (gameTime);
		}
			
		protected override void Draw (GameTime gameTime)
		{
			graphics.GraphicsDevice.Clear (Color.CornflowerBlue);
			spriteBatch.Begin ();
			//Update shuttle rectangle for collision purposes
			ShuttleRectangle.X = shuttlex-x;
			//Stuff for background - note the float multipliers, this gives us the "depth" we're looking for
			//This multiplier should be smaller for things that are farther away
			spriteBatch.Draw(background1,new Vector2(200-(x*0.2f), 100),null,Color.White);
			spriteBatch.Draw(background2,new Vector2(300-(x*0.4f),PLATFORM_TOP-background2.Height),null,Color.White);
			spriteBatch.Draw(background3,new Vector2(500-(x*0.8f),PLATFORM_TOP-background3.Height),null,Color.White);
			//You'd draw your platform here

			//Drawing the sprite and obstacle
			spriteBatch.Draw (image, new Vector2 (200, y), new Rectangle (0, 0, image.Width, image.Height), Color.White);
			spriteBatch.Draw(shuttleimg, new Vector2(shuttlex-x, shuttley), new Rectangle(0,0,shuttleimg.Width,shuttleimg.Height), Color.White);
			spriteBatch.End();
			base.Draw (gameTime);
		}
	}	
}

