//MemoryCell.java
//Generic memory cell class
//COSC 201
//Alan Jamieson

public class MemoryCell<Zach> {
	private Zach storedValue;
	
	public Zach read() {return storedValue;}
	public void write(Zach j) {storedValue = j;}
}
