//myFooClass.java
//implementation example of myInterface
//COSC201
//Alan Jamieson

public class myFooClass implements myInterface{

	public int foo(int a){
		return a * 4;
	}
	
	public void bar(String q, float j){
		System.out.println(q + j);
	}
}
