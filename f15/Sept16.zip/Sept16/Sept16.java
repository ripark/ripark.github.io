//Sept16.java
//Driver for September 16th examples
//COSC 201
//Alan Jamieson

import java.util.*;

public class Sept16 {
	
	public void arrayMemCpy(Object arr1[], Object arr2[]){

			for(int i = 0; i<arr1.length; i++){
				arr2[i] = arr1[i];
			}
	}

	public static void main(String[] args) {
		ArrayList<Integer> a = new ArrayList<Integer>();
		
		MemoryCell<ArrayList<Integer>> m = new MemoryCell<ArrayList<Integer>>();
		MemoryCell<String> n = new MemoryCell<String>();

		String s = "Whoozits";
		m.write(a);
		n.write(s);
		MemoryCell<Integer> arr[] = new MemoryCell[10];
		for(int i = 0; i<10; i++){
			arr[i] = new MemoryCell<Integer>();
		}
	}

}
