//myInterface.java
//simple interface example
//COSC 201
//Alan Jamieson

public interface myInterface {
	public int foo(int a);
	public void bar(String s, float f);
}
