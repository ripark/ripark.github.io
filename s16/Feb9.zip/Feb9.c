#include <stdio.h>

//pass-by-copy
int foo (int a, int b){
  a = a+b;
  return a;
}

//pass-by-reference
void foo2 (int *a, int *b){
  *a = *a+*b;
}

/* 
Passing arrays

One dimensional array:
void arrayFoo(int a[]){

}

Two-dimensional arrays:
void arrayFoo2(int a[][10]){

}
*/

/*
ONLY VALID IN C++
void foo2 (int &a, int &b){
  a = a+b;
}

in main:

  foo2(i,j);

*/
int main(int argc, char **argv){
  int i = 4;
  int j = 5;
  int k = 0;

  k = foo(i,j);
  printf("%d\n", k);
  printf("%d\n", i);

  foo2(&i,&j);
  printf("Pass-by-reference: %d\n", i);

  return 0;
}
