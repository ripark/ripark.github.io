#include <stdio.h>

//Lets talk about structs - a pseudoclass, a way to group data

typedef struct mystruct{
  int x;
  int y;
}point;

int main(int argc, char**argv){
  struct mystruct j;
  j.x = 4;
  point i;
  i.x = 12;

  printf("%d\n", j.x);
  printf("%d\n", i.x);

  point *k = &i;
  k->x = 24; //this means (*k).x
  printf("%d\n", i.x);

  return 0;
}

//Exercise: Create struct typed as foo, with four variables an int,
//a char, a float, and an int pointer. In main, create a variable of
//type foo by utilizing a pointer, initialize all variables, then print
//them out.

