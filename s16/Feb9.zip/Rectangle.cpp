//source file for Rectangle

#include "Rectangle.h"

Rectangle::Rectangle(){
  height = new int(0);
  width = 0;
}

Rectangle::Rectangle(int h, int w){
  height = new int(h);
  width = w;
}

int Rectangle::area(){
  return *height*width;
}

Rectangle::~Rectangle(){
  delete height;
}
