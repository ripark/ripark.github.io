#include <iostream>
#include "Rectangle.h"

using namespace std;

int main(){

  //default constructor
  Rectangle r;

  //non-default constructor
  Rectangle q(4,3);

  //pointers!
  Rectangle *p = new Rectangle(5, 3);

  cout<<"Rectangle 1: "<<r.area()<<endl;
  cout<<"Rectangle 2: "<<q.area()<<endl;
  cout<<"Rectangle 3: "<<p->area()<<endl;

  delete p;

  return 0;
}
