//This is a header file - contains the framework of my class

class Rectangle{
  private:
    int *height;
    int width;
  public:
    Rectangle();
    Rectangle(int, int);
    int area();
    ~Rectangle();
};
