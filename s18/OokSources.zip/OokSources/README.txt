To help simplify the parsing of the Ook! sources I have
not included any comments within those sources. All of the
information I would have included there is included here
instead.

-Alan

Sources translated from brainf*ck code by Daniel B. Cristofani

ook0.txt - Hello, World!
ook1.txt - takes an input and outputs the reverse
ook2.txt - prints a lovely tree!
ook3.txt - prints squares from 0 to 10000
ook4.txt - calculates powers of 2 (does not terminate!, press CTRL-C to halt)

For File I/O - your lisp code will need the full path for the source file.
If you have your file (example: ook0.txt) on your desktop:
  Windows: C:/Users/<your username>/Desktop/ook0.txt
  Mac: /Users/<your username>/Desktop/ook0.txt
