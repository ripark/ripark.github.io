//rectangle.cpp
//Source file for rectangle class
//Alan C. Jamieson
//February 1, 2018
//COSC 251


#include "rectangle.h"

//default, no-argument constructor
rectangle::rectangle() {
    h = 8;
    w = 4;
}

//non-default, parameterized constructor, sets height and width
rectangle::rectangle(int newh, int neww) {
    h = newh;
    w = neww;
}

//calculates and returns the area of the rectangle
int rectangle::area() {
    return h*w;
}
