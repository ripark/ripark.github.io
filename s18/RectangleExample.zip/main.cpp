//main.cpp
//main file for rectangle class example
//Alan C. Jamieson
//February 1, 2018
//COSC 251

#include <iostream>
#include "rectangle.h"

//in order to leave off the std scope on cout,cin,endl
using namespace std;

//main gets height and width from the user, creates a rectangle, then prints area
int main() {

    int temph = 0;
    int tempw = 0;
    cout << "Enter h: ";
    cin >> temph;
    cout << "Enter w: ";
    cin >> tempw;
    rectangle r(temph, tempw);
    cout << r.area() << endl;

    return 0;
}