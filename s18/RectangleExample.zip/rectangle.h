//rectangle.h
//Header file for rectangle class
//Alan C. Jamieson
//February 1, 2018
//COSC 251

#ifndef FEB1_RECTANGLE_H
#define FEB1_RECTANGLE_H

//class definition for rectangle
//  h - height
//  w - width
class rectangle {
  public:
    rectangle();
    rectangle(int, int);
    int area();
  private:
    int h;
    int w;
};


#endif //FEB1_RECTANGLE_H
